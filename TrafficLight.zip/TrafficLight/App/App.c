
#ifndef App
	#include "APP.h"
#endif
extern uint8_t INT0_FLAG, pressCancel;		//Interrupt helper Flag to Ignore Long/double press
extern uint8_t Interrupted_STATE;

uint8_t LED_Sequence[4] = {GREEN, YELLOW, RED, YELLOW};

//Indices :
// 0 ----> Green index
// 1,3 ----> Yellow Indices
// 2 ----> Red Index

int i = 0; //LED_Sequence Iterator , will be used externally to detect state



void appStart(void)
{
	//Initialization and Configuration

	//LED Initialization
	LED_init(portA,0);
	LED_init(portA,1);
	LED_init(portA,2);

	LED_init(portB,0);
	LED_init(portB,1);
	LED_init(portB,2);


	//Pedestrian Button Initialization
	Button_init(portD, 2);

	//Interrupt Configuration
	Sei();
	INT0_init();
	INT0_FLAG = 0; pressCancel = 0;

	//Program Flow
	while (1)
	{
		for(i =0; i<4; i++)
		{
			if(INT0_FLAG ==0)
			{
				LED_off(portA, GREEN);		//turning off green car's led to make sure that it's not on after interruption process

				//Start Normal Mode ---------------------------------------------------------------------------------------------
				//	*NOTE: We can un-hash the following to make the 6 LEDs work in the same time
				if (LED_Sequence[i] == YELLOW)		//Yellow
				{
					//Blinking Yellow LED for 5 Seconds
					for(uint8_t r=0; r<10; r++)
					{
						DIO_toggle(portA,1);		//DIO_toggle(portB,1);
						DELAY_500ms();
					}
					LED_off(portA, 1);				//LED_off(portB, 1);
				}//end if
				else				//Red or green
				{
					LED_on(portA, LED_Sequence[i]);		//LED_on(portB, 2-LED_Sequence[i]);
					DELAY_5s();
					LED_off(portA, LED_Sequence[i]);	//LED_off(portB, 2-LED_Sequence[i]);
				}//end else
				//Stop Normal Mode ---------------------------------------------------------------------------------------------
		}//end if
			//Interrupt Handling
			else
			{
				if(Interrupted_STATE == RED)
				{
					//Car's Red Led will be on for 5s ,also Pedestrian's Green Led
					LED_on(portA, RED);		//Cars --> RED on
					LED_on(portB, GREEN);	//Pedestrian --> GREEN on
					DELAY_5s();				//wait 5s
				}//end if
				else
				{   //Green or Yellow
					LED_on(portB, RED);
					//Blinking Yellow LED for 5 Seconds
					for(uint8_t r=0; r<10; r++)
					{
						DIO_toggle(portA, YELLOW);DIO_toggle(portB, YELLOW);
						DELAY_500ms();
					}
					LED_off(portB, RED);

					LED_on(portB, GREEN);
					LED_on(portA, RED);
					DELAY_5s();
				}//end else

				LED_off(portA, RED);		//Cars RED --> off

				//Blinking Yellow LED for 5 Seconds
				for(uint8_t r=0; r<10; r++)
				{
				    //10 times delay each for 0.5 second means 5s delay
					DIO_toggle(portA, YELLOW);DIO_toggle(portB, YELLOW);
					DELAY_500ms();
				}
				LED_off(portA, YELLOW);LED_off(portB, YELLOW);      //turn off both yellow leds
				LED_off(portB, GREEN);                              //turn off pedestrian green led
				LED_on(portB, RED);		//Pedestrian --> RED on
				LED_on(portA, GREEN);	//Cars --> GREEN on

				DELAY_5s();				//wait 5s
				LED_off(portB, RED);    //turn off pedestrian red LED

				i = -1;		            //to go to green car led and cancel "for" auto increment

				Interrupted_STATE = 8;	//8 is a predefined value to reset
				INT0_FLAG = 0;			//now we can accept new interrupts
				pressCancel = 0;        //now user pressing won't be ignored anymore
			}//end else
		}//end for
	}//end super while
}//end appStart()


