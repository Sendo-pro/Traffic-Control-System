

#ifndef Registers
	#include "../HAL/MCAL/Registers.h"
#endif

#ifndef DIO
	#include "../HAL/MCAL/DIO/DIO.h"
#endif  //DIO

#ifndef Interrupt
	#include "../HAL/MCAL/Interrupt/Interrupt.h"
#endif  //Interrupt

#ifndef Button
	#include "../HAL/ECUAL/Button/Button.h"
#endif //Button

#ifndef LED
	#include "../HAL/ECUAL/LED/LED.h"
#endif

#ifndef App
	#define App
	void appStart(void);
#endif
