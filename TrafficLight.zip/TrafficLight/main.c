/*
 * TrafficLight.c
 * Description : A program to run on ATmega 32, manage traffic light system 
 * Author : AbdulRahman AlSindiony
 */ 

//#ifndef App
	#include "App/App.h"
//#endif


int main(void)
{
    /* Replace with your application code */
    appStart();
	return 0;
}

