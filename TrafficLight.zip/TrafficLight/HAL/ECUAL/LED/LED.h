#ifndef DIO
	#include "../../MCAL/DIO/DIO.h"
#endif // DIO

#ifndef Timer
	#include "../../MCAL/Timer/Timer.h"
#endif

#ifndef LED
#define LED

void LED_init(uint8_t PORT, uint8_t PIN);		//Initialize LED Pin
void LED_on(uint8_t PORT, uint8_t PIN);			
void LED_off(uint8_t PORT, uint8_t PIN);
void LED_blink(uint8_t PORT, uint8_t PIN);

#endif