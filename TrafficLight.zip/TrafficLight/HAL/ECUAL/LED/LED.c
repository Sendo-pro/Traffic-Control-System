#ifndef LED
	#include "LED.h"
#endif

void LED_init(uint8_t PORT, uint8_t PIN)
{
	DIO_init(PORT, PIN, DIR_WRITE);
}

void LED_on(uint8_t PORT, uint8_t PIN)
{
	DIO_write(PORT, PIN, 1);
}

void LED_off(uint8_t PORT, uint8_t PIN)
{
	DIO_write(PORT, PIN, 0);
}

void LED_blink(uint8_t PORT, uint8_t PIN)
{
	DELAY_500ms();
	DIO_toggle(PORT, PIN);
}
