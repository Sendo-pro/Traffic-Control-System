#ifndef Button
	#include "Button.h"
#endif

void Button_init(uint8_t PORT, uint8_t PIN)
{
	DIO_init(PORT, PIN, DIR_READ);
}

uint8_t Button_read(uint8_t PORT, uint8_t PIN)
{
	return DIO_read(PORT, PIN);
}