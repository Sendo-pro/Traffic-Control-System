#ifndef DIO
	#include "../../MCAL/DIO/DIO.h"
#endif // DIO

#ifndef Button
	#define Button
	void Button_init(uint8_t PORT, uint8_t PIN);
	uint8_t Button_read(uint8_t PORT, uint8_t PIN);
#endif