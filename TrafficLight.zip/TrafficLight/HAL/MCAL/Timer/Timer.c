#ifndef Timer
	#include "Timer.h"
#endif //Timer

/************************************************************************/
/* Timer APIs                                                           */
/************************************************************************/

//Function To Generate 5s Delay
void DELAY_5s(void)
{
	uint8_t OVERFLOWS = 0;
	while (OVERFLOWS < 20)
	{
		//  1- Choosing Timer Mode
		TCCR0 = 0x00;
		//  2- Setting Timer Value
		TCNT0 = 0x0C;
		//  3- Setting Prescalar and start counting
		TCCR0 = 0x05;
		//  4- Detect OverFlows
		while((TIFR & (1<<0)) == 0);
		//  5- Count OverFlows
		OVERFLOWS++;
		//  6- Clearing Interrupt Flag
		TIFR |= (1<<0);
	}
	//  7- Stopping Timer
	TCCR0 = 0x00;
}

//Function To Generate 1s Delay
void DELAY_500ms(void)
{
	uint8_t OVERFLOWS = 0;
	while (OVERFLOWS < 2)
	{
		//  1- Choosing Timer Mode
		TCCR0 = 0x00;
		//  2- Setting Timer Value
		TCNT0 = 0x0C;
		//  3- Setting Prescalar and start counting
		TCCR0 = 0x05;
		//  4- Detect OverFlows
		while((TIFR & (1<<0)) == 0);
		//  5- Count OverFlows
		OVERFLOWS++;
		//  6- Clearing Interrupt Flag
		TIFR |= (1<<0);
	}
	//  7- Stopping Timer
	TCCR0 = 0x00;
	
}