#ifndef Registers
	#include "../Registers.h"
#endif

#ifndef Timer
	#define Timer
	void DELAY_5s(void);
	void DELAY_500ms(void);
#endif