#ifndef DIO
    #include "DIO.h"
#endif // DIO


void DIO_init(uint8_t PORT, uint8_t PIN, uint8_t DIR)
{
    switch (PORT){
        case portA:
            (DIR == 1) ? SET(DDRA,PIN):RESET(DDRA,PIN);break;
        case portB:
            (DIR == 1) ? SET(DDRB,PIN):RESET(DDRB,PIN);break;
        case portC:
            (DIR == 1) ? SET(DDRC,PIN):RESET(DDRC,PIN);break;
        case portD:
            (DIR == 1) ? SET(DDRD,PIN):RESET(DDRD,PIN);break;
    }
}
void DIO_write(uint8_t PORT, uint8_t PIN, uint8_t Value)
{
    switch (PORT){
        case portA:
            (Value == 1) ? SET(PORTA,PIN):RESET(PORTA,PIN);break;
        case portB:
            (Value == 1) ? SET(PORTB,PIN):RESET(PORTB,PIN);break;
        case portC:
            (Value == 1) ? SET(PORTC,PIN):RESET(PORTC,PIN);break;
        case portD:
            (Value == 1) ? SET(PORTD,PIN):RESET(PORTD,PIN);break;
    }
}
void DIO_toggle(uint8_t PORT, uint8_t PIN)
{
    switch (PORT){
        case portA:
            ( ((PORTA & (1<<PIN))>>PIN) == 1) ? RESET(PORTA,PIN):SET(PORTA,PIN);break;
        case portB:
            ( ((PORTB & (1<<PIN))>>PIN) == 1) ? RESET(PORTB,PIN):SET(PORTB,PIN);break;
        case portC:
            ( ((PORTC & (1<<PIN))>>PIN) == 1) ? RESET(PORTC,PIN):SET(PORTC,PIN);break;
        case portD:
            ( ((PORTD & (1<<PIN))>>PIN) == 1) ? RESET(PORTD,PIN):SET(PORTD,PIN);break;
    }
}
uint8_t DIO_read(uint8_t PORT, uint8_t PIN)
{
    switch (PORT){
        case portA:
            return ((PORTA & (1<<PIN))>>PIN);
        case portB:
            return ((PORTB & (1<<PIN))>>PIN);
        case portC:
            return ((PORTC & (1<<PIN))>>PIN);
        case portD:
            return ((PORTD & (1<<PIN))>>PIN);
    }
	return 2;
}
