
#ifndef Registers
	#include "../Registers.h"
#endif // Registers


#ifndef DIO
#define DIO


#define portA 0
#define portB 1
#define portC 2
#define portD 3


#define DIR_WRITE 0
#define DIR_READ 1


#define SET(port , pin) (port |= (1<<pin))
#define RESET(port , pin) (port &= (~(1<<pin)))




void DIO_init(uint8_t PORT, uint8_t PIN, uint8_t DIR);
void DIO_write(uint8_t PORT, uint8_t PIN, uint8_t Value);
void DIO_toggle(uint8_t PORT, uint8_t PIN);
uint8_t DIO_read(uint8_t PORT, uint8_t PIN);

#endif // DIO
