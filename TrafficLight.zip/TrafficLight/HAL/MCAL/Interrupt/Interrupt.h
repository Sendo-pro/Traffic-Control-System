#ifndef Registers
	#include "../Registers.h"
#endif //Registers


#ifndef Interrupt
	#define Interrupt
  
	//For Code Readability
	#define GREEN 0
	#define YELLOW 1
	#define RED 2

  
	/*External Interrupt Request 0*/
	#define EXT_INT_0 __vector_1

	/*Macro Defines The ISR*/
	#define ISR(INT_VECT) void INT_VECT(void) __attribute__ ((signal,used));\
	void INT_VECT(void)
	
	/*Function To Initialize EXT_INT_0*/
	void INT0_init(void);
	
	/*Function To Set Global Interrupt Flag*/
	void Sei(void);
#endif  //Interrupt

