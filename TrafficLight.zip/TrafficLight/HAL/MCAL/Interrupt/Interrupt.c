#ifndef DIO
	#include "../DIO/DIO.h"
#endif // DIO

#ifndef Interrupt
	#include "Interrupt.h"
#endif //Interrupt

//Global Variables that will be used by other files
extern int i;
uint8_t INT0_FLAG = 0 ;				//Variable to process interrupts
uint8_t pressCancel = 0;			//Variable to cancel multiple presses at the same time
uint8_t Interrupted_STATE = 8;		//Variable to store the interrupted state

/*Function To Set Global Interrupt Flag*/
void Sei(void)
{
	SREG |= (1<<7);
}

/*Function To Initialize EXT_INT_0*/
void INT0_init(void)
{
	//  Choosing Interrupt Sense Control
	//  Sensing On Falling Edge To act When The User Leaves The Button
	SET(MCUCR, 1);
	RESET(MCUCR, 0);
	
	//  Enabling External Interrupt To Start Sensing
	SET(GICR, 6);
}

/*Interrupt Service Routine of EXT_INT_0*/
ISR(EXT_INT_0)
{
	//1- Checking for no current interrupts or previous presses that is not handled yet
  if ( (INT0_FLAG == 0) && (pressCancel == 0) )
  {
	  INT0_FLAG = 1;			//To indicate the occurrence of an interrupt
	  Interrupted_STATE = i;	//storing the interrupted state from the loop iterator i
	  pressCancel = 1;			//Guarding the press button to cancel any coming presses before resetting pressCancel
  }
  
}